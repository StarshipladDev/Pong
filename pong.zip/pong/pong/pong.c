#include <stdio.h>
#include <stdlib.h>
#include <SDL2/SDL.h>
#include <SDL2_image/SDL_image.h>
#include <math.h>
#define PI 3.14159265
const int SCREEN_WIDTH = 1200;
const int SCREEN_HEIGHT = 700;
const int PADDLE_WIDTH = 20;
const int PADDLE_HEIGHT = 100;

const double MAX_BOUNCE = (5*PI)/12;

typedef struct {
  SDL_Renderer *renderer;
  SDL_Window *window;
  SDL_Surface *scoremap;
  SDL_Texture *endScreen;
  SDL_Texture *titleScreen;
  SDL_Texture *playAgain;
  int up;
  int down;
  int left;
  int right;
  int roundDone;
  int gameFinished;
  int gameStart;
  int rally;
} App;

typedef struct {
  int x;
  int y;
  int left;
  int factor;
  int vx;
  int vy;
  SDL_Texture *texture;
  int width;
  int height;
} Ball;

typedef struct {
  int x;
  int y;
  int left;
  int height;
  int width;
  int speed;
} Paddle;

typedef struct {
  SDL_Texture *playerScore;
  SDL_Texture *compScore;
  int score[2];
} ScoreBoard;

typedef struct {
  int top;
  int bottom;
  int right;
  int left;
  int width;
} Border;

typedef struct {
  int spawned;
  int spawnRate;
  int height;
  int speedUp;
  int slowDown;
  int enlarge;
  int shrink;
  int powerups;
  int speedUpLoc[2];
  int slowDownLoc[2];
  int shrinkLoc[2];
  int enlargeLoc[2];
  SDL_Texture *speedUpImg;
  SDL_Texture *slowDownImg;
  SDL_Texture *enlargeImg;
  SDL_Texture *shrinkImg;
} PowerUp;

static App app;
static Paddle player;
static Paddle computer;
static Ball ball;
static ScoreBoard scoreBoard;
static Border border;
static PowerUp powerUp;
static int pScoreCoor[] = {430, 0};
static int cScoreCoor[] = {700, 0};
static char playerPictures[10][15] = {"images/0p.png","images/1p.png" ,"images/2p.png" ,"images/3p.png" ,"images/4p.png" , "images/5p.png",
				      "images/6p.png" ,"images/7p.png" ,"images/8p.png" ,"images/9p.png"};
static char compPictures[10][15] = {"images/0c.png","images/1c.png" ,"images/2c.png" ,"images/3c.png" ,"images/4c.png" , "images/5c.png",
				    "images/6c.png" ,"images/7c.png" ,"images/8c.png" ,"images/9c.png"};

void initSDL(void) {
  int rendererFlags, windowFlags;
  rendererFlags = SDL_RENDERER_ACCELERATED;	
  windowFlags = 0;

  if (SDL_Init(SDL_INIT_VIDEO) < 0) {
    printf("Could not initialize SDL: %s\n", SDL_GetError());
    exit(1);
  }

  app.window = SDL_CreateWindow("Pong", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, windowFlags);
	
  if (!app.window) {
    printf("Failed to open window\n");
    exit(1);
  }

  SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "linear");
  app.renderer = SDL_CreateRenderer(app.window, -1, rendererFlags);
	
  if (!app.renderer) {
    printf("Failed to create renderer: %s\n", SDL_GetError());
    exit(1);
  }
}

void close_pong() {	
  SDL_DestroyRenderer(app.renderer);
  SDL_DestroyWindow(app.window);
  app.window = NULL;
  app.renderer = NULL;
  IMG_Quit();
  SDL_Quit();
}

void doKeyDown(SDL_KeyboardEvent *event) {
  if (event->repeat == 0) {
    if (event->keysym.scancode == SDL_SCANCODE_UP) {
      app.up = 1;
    }
    if (event->keysym.scancode == SDL_SCANCODE_DOWN) {
      app.down = 1;
    }
    if (event->keysym.scancode == SDL_SCANCODE_SPACE && app.gameFinished == 1) {
      app.gameFinished = 0;
    }
    if (event->keysym.scancode == SDL_SCANCODE_SPACE && app.gameStart == 0) {
      app.gameStart = 1;
    }
  }
}

void doKeyUp(SDL_KeyboardEvent *event) {
  if (event->repeat == 0) {
    if (event->keysym.scancode == SDL_SCANCODE_UP) {
      app.up = 0;
    }
    if (event->keysym.scancode == SDL_SCANCODE_DOWN) {
      app.down = 0;
    }	
  }
}

void doInput(void) {
  SDL_Event event;	
  while (SDL_PollEvent(&event)) {
    switch (event.type) {
    case SDL_QUIT:
      close_pong();
      exit(0);
      break;
    case SDL_KEYDOWN:
      doKeyDown(&event.key);
      break;				
    case SDL_KEYUP:
      doKeyUp(&event.key);
      break;
    default:
      break;
    }
  }
}

void prepareScene(void) {
  SDL_SetRenderDrawColor(app.renderer, 0, 0, 0, 255);
  SDL_RenderClear(app.renderer);
}

void presentScene(void) {
  SDL_RenderPresent(app.renderer);
}



SDL_Texture *loadTexture(char *filename) {
  SDL_Texture *texture;
  texture = IMG_LoadTexture(app.renderer, filename);
  return texture;
}

void blit(SDL_Texture *texture, int x, int y) {
  SDL_Rect dest;
  dest.x = x;
  dest.y = y;
  SDL_QueryTexture(texture, NULL, NULL, &dest.w, &dest.h);	
  SDL_RenderCopy(app.renderer, texture, NULL, &dest);
}

void blit_paddle(int x, int y, Paddle p, int comp){
  SDL_Rect paddle;
  paddle.x = x;
  paddle.y = y;
  paddle.w = 20;
  paddle.h = p.height;
  if(comp){
    SDL_SetRenderDrawColor(app.renderer, 244, 78, 18, 255 );
  }else{
    SDL_SetRenderDrawColor(app.renderer, 0, 0, 255, 255 );
  }
  
  SDL_RenderFillRect(app.renderer, &paddle);
}

void blit_ball(int x, int y){
  SDL_Rect ball;
  ball.x = x;
  ball.y = y;
  ball.w = 20;
  ball.h = 20;
  SDL_SetRenderDrawColor(app.renderer, 255, 255, 255, 255);
  SDL_RenderFillRect(app.renderer, &ball);
}

void blit_middle(int x, int y, int w, int h){
  SDL_Rect mid;
  mid.x = x;
  mid.y = y;
  mid.w = w;
  mid.h = h;
  SDL_SetRenderDrawColor(app.renderer, 255, 255, 255, 255 );
  SDL_RenderFillRect(app.renderer, &mid);
}

void drawKit(){
  if(app.gameFinished != 1){
    blit(scoreBoard.playerScore, pScoreCoor[0], pScoreCoor[1]);
    blit(scoreBoard.compScore, cScoreCoor[0], cScoreCoor[1]);
  }else{
    blit(app.playAgain, 100, 0);
  }
  blit_paddle(player.x, player.y, player, 0);
  blit_paddle(computer.x, computer.y, computer, 1);
  blit_ball(ball.x, ball.y);
  blit_middle(50, 70, 15, SCREEN_HEIGHT-140); // left
  blit_middle(SCREEN_WIDTH-50, 70, 15, SCREEN_HEIGHT-140); // right
  blit_middle(50, SCREEN_HEIGHT-70, SCREEN_WIDTH-85, 15); // bottom
  blit_middle(50, 70, SCREEN_WIDTH-85, 15); 
}

void gameOver(int compWon){
  if(compWon){
    app.endScreen = loadTexture("images/cwins.png");
  }else{
    app.endScreen = loadTexture("images/pwins.png");
  }
  SDL_Event event;
  int waiting = 1;
  while (app.gameFinished) {
    prepareScene();
    doInput();
    drawKit();
    if(compWon){
      blit(app.endScreen, 620, border.top + 50);
    }else{
      blit(app.endScreen, border.left + 25, border.top + 50);
    }
    presentScene();
    SDL_Delay(16);
  }
}

void spawnPowerUp(){
  int randomNumber = rand() % 4;
  int randx = (rand() % 801) + 200;
  int randy = (rand() % ((border.bottom - powerUp.height) - border.top + 10)) + (border.top + 10);
  if(randomNumber == 0 && powerUp.speedUp != 1){
    powerUp.speedUp = 1;
    powerUp.speedUpLoc[0] = randx;
    powerUp.speedUpLoc[1] = randy;
  }else if(randomNumber == 1 && powerUp.slowDown != 1){
    powerUp.slowDown = 1;
    powerUp.slowDownLoc[0] = randx;
    powerUp.slowDownLoc[1] = randy;
  }else if(randomNumber == 2 && powerUp.enlarge != 1){
    powerUp.enlarge = 1;
    powerUp.enlargeLoc[0] = randx;
    powerUp.enlargeLoc[1] = randy;
  }else if(randomNumber == 3 && powerUp.shrink != 1){
    powerUp.shrink = 1;
    powerUp.shrinkLoc[0] = randx;
    powerUp.shrinkLoc[1] = randy;
  }
}

void drawPowerUp(){
  if(powerUp.speedUp){
    blit(powerUp.speedUpImg, powerUp.speedUpLoc[0],powerUp.speedUpLoc[1]);
  }if(powerUp.slowDown){
    blit(powerUp.slowDownImg, powerUp.slowDownLoc[0],powerUp.slowDownLoc[1]);
  }if(powerUp.enlarge){
    blit(powerUp.enlargeImg, powerUp.enlargeLoc[0],  powerUp.enlargeLoc[1]);
  }if(powerUp.shrink){
    blit(powerUp.shrinkImg, powerUp.shrinkLoc[0], powerUp.shrinkLoc[1]);
  }
}

void calc_velocity(int comp) {
  double relative_intersection;
  double normalized_intersection;
  double bounceAngle;
  if(comp){
    relative_intersection = computer.height/2 - (computer.height - (ball.y - computer.y));
    normalized_intersection = (relative_intersection / (computer.height/2));
  }else{
    relative_intersection = player.height/2 - (player.height - (ball.y - player.y));
    normalized_intersection = (relative_intersection / (player.height/2));
  }  
  bounceAngle = normalized_intersection * MAX_BOUNCE;
  ball.vy = 5 * sin(bounceAngle);
  app.rally += 1;
  if(app.rally % powerUp.spawnRate == 0 && app.rally != 0){
    spawnPowerUp();
  }
}

int powerUpCollision(int x, int y){
  if((((x <= ball.x && ball.x <= x + powerUp.height) || (x <= ball.x + ball.height && ball.x + ball.height <= x + powerUp.height)) &&
      ((y <= ball.y && ball.y <= y + powerUp.height) || (y <= ball.y + ball.height && ball.y + ball.height <= y + powerUp.height)))){
    return 1;
  }else{
    return 0;
  }
}

// player y == top
void check_collision(){
  if(ball.x == 120 && (player.y- ball.height <= ball.y && ball.y <= player.y+100)){
    ball.left = 0;
    calc_velocity(0);
  }else if(ball.x >= border.right - border.width){ // player won point.
    ball.left = 1;
    app.roundDone = 1;
    scoreBoard.score[0] += 1;
    if(scoreBoard.score[0] == 10){
      app.gameFinished = 1;
    }
    scoreBoard.playerScore = loadTexture(playerPictures[scoreBoard.score[0]]);
  }else if(ball.x <= border.left){ // comp won point.
    ball.left = 0;
    app.roundDone = 1;
    scoreBoard.score[1] += 1;
    if(scoreBoard.score[1] == 10){
      app.gameFinished = 1;
    }
    scoreBoard.compScore = loadTexture(compPictures[scoreBoard.score[1]]);
  }
  else if(ball.y + ball.height >= border.bottom || ball.y <= border.top){ // bounce off bottom or top.
    ball.vy = ball.vy * -1;
  }else if(ball.x == SCREEN_WIDTH - 120 && ((ball.y + ball.height) >= computer.y && computer.y + computer.height >= ball.y)){
    calc_velocity(1);
    ball.left = 1;
  }if(powerUp.speedUp && powerUpCollision(powerUp.speedUpLoc[0], powerUp.speedUpLoc[1])){
    if(ball.left){
      computer.speed = 8;
    }else{
      player.speed = 8;
    }
    powerUp.speedUp = 0;
  }else if(powerUp.slowDown && powerUpCollision(powerUp.slowDownLoc[0], powerUp.slowDownLoc[1])){
    if(ball.left){
      computer.speed = 2;
    }else{
      player.speed = 2;
    }
    powerUp.slowDown = 0;
  }else if(powerUp.enlarge && powerUpCollision(powerUp.enlargeLoc[0], powerUp.enlargeLoc[1])){
    if(ball.left){
      computer.height = 150;
    }else{
      player.height = 150;
    }
    powerUp.enlarge = 0;
  }else if(powerUp.shrink && powerUpCollision(powerUp.shrinkLoc[0], powerUp.shrinkLoc[1])){
    if(ball.left){
      computer.height = 75;
    }else{
      player.height = 75;
    }
    powerUp.shrink = 0;
  }
}

void moveComputer(){
  if(ball.y + ball.height <= computer.y){
    computer.y -= computer.speed;
  }else if(computer.y + computer.height <= ball.y){
    computer.y += computer.speed;
  }
}

void setPos(){
  app.roundDone = 0;
  app.rally = 0;
  player.x = 100;
  player.y = 300;
  player.speed = 4;
  player.height = PADDLE_HEIGHT;
  
  computer.x = SCREEN_WIDTH - 100;
  computer.y = 300;
  computer.speed = 4;
  computer.height = PADDLE_HEIGHT;
  
  ball.x = 600;
  ball.y = 250 + (rand() % 201);
  ball.left = rand() % 2;
  
  ball.vx = 10;
  ball.vy = 0;

  powerUp.spawned = 0;
  powerUp.speedUp = 0;
  powerUp.slowDown = 0;
  powerUp.enlarge = 0;
  powerUp.shrink = 0;
}

void runGame(){
  while (!app.gameFinished) {
    if(app.roundDone){
      setPos();
    }
    prepareScene();
    doInput();
    if (app.up && player.y >= border.top) {
      player.y -= player.speed;
    }
		
    if (app.down && (player.y + player.height <= border.bottom)) {
      player.y += player.speed;
    }
    if(!ball.left){
      moveComputer();
    }
    if(ball.left){
      ball.x -= ball.vx;
    }else{
      ball.x += ball.vx;
    }
    ball.y += ball.vy;
    drawKit();
    int y = border.top - 15;
    for(int i = 0; i < 8; i++){
      blit_middle(595, y, 10, 40);
      y += 75;
    }
    drawPowerUp();
    presentScene();
    check_collision();
    SDL_Delay(16);
  }
}

int main( int argc, char* args[]){
  memset(&app, 0, sizeof(App));
  memset(&player, 0, sizeof(Paddle));
  memset(&ball, 0, sizeof(Ball));
  memset(&computer, 0, sizeof(Paddle));
  memset(&scoreBoard, 0, sizeof(ScoreBoard));
  memset(&border, 0, sizeof(Border));
  memset(&powerUp, 0, sizeof(PowerUp));
  
  initSDL();
  player.width = PADDLE_WIDTH;

  computer.width = PADDLE_WIDTH;

  setPos();

  ball.width = 20;
  ball.height = 20;

  app.gameFinished = 0;
  app.gameStart = 0;
  app.titleScreen = loadTexture("images/title.png");
  app.playAgain = loadTexture("images/playagain.png");
  
  border.width = 15;
  //border.top = 70 + (int)(ball.width/2);
  border.top = 70 + border.width;
  border.bottom = SCREEN_HEIGHT-70;
  border.left = 50 + border.width;
  border.right = SCREEN_WIDTH - 50;

  powerUp.height = 20;
  powerUp.spawnRate = 2;
  powerUp.speedUpImg = loadTexture("images/speedup.png");
  powerUp.slowDownImg = loadTexture("images/slowdown.png");
  powerUp.enlargeImg = loadTexture("images/enlarge.png");
  powerUp.shrinkImg = loadTexture("images/shrink.png");
 
  while(!app.gameStart){
    prepareScene();
    doInput();
    blit(scoreBoard.playerScore, pScoreCoor[0], pScoreCoor[1]);
    blit(scoreBoard.compScore, cScoreCoor[0], cScoreCoor[1]);
    blit_paddle(player.x, player.y, player, 0);
    blit_paddle(computer.x, computer.y, computer, 1);
    blit(app.titleScreen, 0, 0);
    blit_middle(50, 70, 15, SCREEN_HEIGHT-140); // left
    blit_middle(SCREEN_WIDTH-50, 70, 15, SCREEN_HEIGHT-140); // right
    blit_middle(50, SCREEN_HEIGHT-70, SCREEN_WIDTH-85, 15); // bottom
    blit_middle(50, 70, SCREEN_WIDTH-85, 15); // top
    presentScene();
  }

  while(1){
    scoreBoard.playerScore = loadTexture("images/0p.png");
    scoreBoard.compScore = loadTexture("images/0c.png");
    scoreBoard.score[0] = 0;
    scoreBoard.score[1] = 0;						      
    runGame();
    if(scoreBoard.score[0] == 10){
      gameOver(0);
    }else{
      gameOver(1);
    }
    setPos();
  }
  close_pong();
  return EXIT_SUCCESS;
}
