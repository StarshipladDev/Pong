#include <stdio.h>
#include <stdlib.h>
#include <SDL2/SDL.h>
#include <SDL2_image/SDL_image.h>
#include <SDL2_mixer/SDL_mixer.h>
#include <math.h>
#include <time.h>
#define PI 3.14159265
const int SCREEN_WIDTH = 1200;
const int SCREEN_HEIGHT = 700;
const int PADDLE_WIDTH = 20;
const int PADDLE_HEIGHT = 100;

const double MAX_BOUNCE = (5*PI)/12;

typedef struct {
  SDL_Renderer *renderer;
  SDL_Window *window;
  SDL_Surface *scoremap;
  SDL_Texture *endScreen;
  SDL_Texture *titleScreen;
  SDL_Texture *playAgain;
  SDL_Texture *returnMenu;
  SDL_Texture *difficulty;
  SDL_Texture *easyDifficulty;
  SDL_Texture *hardDifficulty;
  SDL_Texture *info;
  SDL_Texture *play;
  SDL_Texture *color;
  SDL_Texture *arrow;
  SDL_Texture *arrowup;
  SDL_Texture *background;
  SDL_Texture *mode;
  SDL_Texture *infoText;
  SDL_Texture *interact;
  SDL_Texture *classicImg;
  SDL_Texture *doublesImg;
  SDL_Texture *initialsImg;
  int up;
  int down;
  int netUp;
  int netDown;
  int left;
  int right;
  int roundDone;
  int gameFinished;
  int gameStart;
  int rally;
  int menuEnter;
  int hardDiff;
  int classic;
  int selectingDiff;
  int selectingDesigns;
  int selectingMode;
  int onInfo;
  int colors;
  int muted;
  int restarted;
  int quited;
} App;

typedef struct {
  int x;
  int y;
  int left;
  int factor;
  int vx;
  int vy;
  SDL_Texture *texture;
  int width;
  int height;
  int reached;
} Ball;

typedef struct {
  int x;
  int y;
  int left;
  int height;
  int width;
  int speed;
  int color;
} Paddle;

typedef struct {
  SDL_Texture *playerScore;
  SDL_Texture *compScore;
  int score[2];
} ScoreBoard;

typedef struct {
  int top;
  int bottom;
  int right;
  int left;
  int width;
} Border;

typedef struct {
  int spawned;
  int spawnRate;
  int height;
  int speedUp;
  int slowDown;
  int enlarge;
  int shrink;
  int lightgood;
  int lightbad;
  int compLight;
  int playerLight;
  int powerups;
  int speedUpLoc[2];
  int slowDownLoc[2];
  int shrinkLoc[2];
  int enlargeLoc[2];
  int lightgoodLoc[2];
  int lightbadLoc[2];
  SDL_Texture *speedUpImg;
  SDL_Texture *slowDownImg;
  SDL_Texture *enlargeImg;
  SDL_Texture *shrinkImg;
  SDL_Texture *lightgoodImg;
  SDL_Texture *lightbadImg;
} PowerUp;

static App app;
static Paddle player;
static Paddle computer;
static Paddle playerNet;
static Paddle computerNet;
static Ball ball;
static Ball invisibleBall;
static ScoreBoard scoreBoard;
static Border border;
static PowerUp powerUp;
Mix_Music *music1 = NULL;
Mix_Music *music2 = NULL;
Mix_Music *music3 = NULL;
time_t speedUpStartP, slowDownStartP, enlargeStartP, shrinkStartP, lightbadStartP;
time_t speedUpStartC, slowDownStartC, enlargeStartC, shrinkStartC, lightbadStartC;
static int menu = 1;
static int menuCheck = 1;
static int pScoreCoor[] = {430, 0};
static int cScoreCoor[] = {700, 0};
static char playerPictures[10][15] = {"images/0p.png","images/1p.png" ,"images/2p.png" ,"images/3p.png" ,"images/4p.png" , "images/5p.png",
				      "images/6p.png" ,"images/7p.png" ,"images/8p.png" ,"images/9p.png"};
static char compPictures[10][15] = {"images/0c.png","images/1c.png" ,"images/2c.png" ,"images/3c.png" ,"images/4c.png" , "images/5c.png",
				    "images/6c.png" ,"images/7c.png" ,"images/8c.png" ,"images/9c.png"};
static int soundCounter = 0;

int initSound() {
    if( Mix_OpenAudio( 22050, MIX_DEFAULT_FORMAT, 2, 4096 ) == -1 ) {
        return 0;
    }
    return 1;
}
/*
 * Initializes the SDL framework, window and sound.
 * Should be called once
 */
void initSDL(void) {
  int rendererFlags, windowFlags;
  rendererFlags = SDL_RENDERER_ACCELERATED;
  windowFlags = 0;

  if (SDL_Init(SDL_INIT_VIDEO) < 0) {
    printf("Could not initialize SDL: %s\n", SDL_GetError());
    exit(1);
  }

  app.window = SDL_CreateWindow("Pong", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, windowFlags);

  if (!app.window) {
    printf("Failed to open window\n");
    exit(1);
  }

  SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "linear");
  app.renderer = SDL_CreateRenderer(app.window, -1, rendererFlags);

  if (!app.renderer) {
    printf("Failed to create renderer: %s\n", SDL_GetError());
    exit(1);
  }
  if(initSound()==0){
    printf("Failed to create Music:\n");
    exit(1);
  }
}
/*
 * Closes the application.
 */
void close_pong() {
  Mix_FreeMusic(music1);
  Mix_FreeMusic(music2);
  Mix_FreeMusic(music3);
  Mix_CloseAudio();
  SDL_DestroyRenderer(app.renderer);
  SDL_DestroyWindow(app.window);
  app.window = NULL;
  app.renderer = NULL;
  IMG_Quit();
  SDL_Quit();
}
/*
 * Called when the user pressed down on a key.
 */
void doKeyDown(SDL_KeyboardEvent *event) {
  if (event->repeat == 0) {
    if (event->keysym.scancode == SDL_SCANCODE_W) {
      app.up = 1;
    }
    if (event->keysym.scancode == SDL_SCANCODE_S) {
      app.down = 1;
    }
    if(!app.classic){ 
      if (event->keysym.scancode == SDL_SCANCODE_UP){
        app.netUp = 1;
      } if (event->keysym.scancode == SDL_SCANCODE_DOWN){
        app.netDown = 1;
      }
    }
  }
  if (event->keysym.scancode == SDL_SCANCODE_SPACE && app.gameFinished == 1) {
    app.gameFinished = 0;
  }
  if (event->keysym.scancode == SDL_SCANCODE_RETURN && app.gameFinished == 1) {
      app.gameFinished = 0;
      app.gameStart = 0;
      app.menuEnter = 0;
  }
  if (event->keysym.scancode == SDL_SCANCODE_SPACE && app.gameStart == 0 && menu != 1) {
    app.gameStart = 1;
  }
}
/*
 * Called when the user has released the keystroke.
 */
void doKeyUp(SDL_KeyboardEvent *event) {
  if (event->repeat == 0) {
    if(event->keysym.scancode == SDL_SCANCODE_N){
      soundCounter = (soundCounter + 1) % 3;
      if(soundCounter == 0){
        Mix_PlayMusic(music1, -1);
      }else if(soundCounter == 1){
        Mix_PlayMusic(music2, -1);
      }else{
        Mix_PlayMusic(music3, -1);
      }
    }if (event->keysym.scancode == SDL_SCANCODE_W) {
      app.up = 0;
    } if (event->keysym.scancode == SDL_SCANCODE_S) {
      app.down = 0;
    } if (menu && (event->keysym.scancode == SDL_SCANCODE_UP || event->keysym.scancode == SDL_SCANCODE_W)){
      menuCheck--;
    } if (menu && (event->keysym.scancode == SDL_SCANCODE_DOWN || event->keysym.scancode == SDL_SCANCODE_S)){
      menuCheck++;
    }
    if(!app.classic){
      if(event->keysym.scancode == SDL_SCANCODE_UP){
        app.netUp = 0;
      } if(event->keysym.scancode == SDL_SCANCODE_DOWN){
        app.netDown = 0;
      }
    } if (event->keysym.scancode == SDL_SCANCODE_SPACE && menu == 1) {
      app.menuEnter = 1;
    } if ((event->keysym.scancode == SDL_SCANCODE_RIGHT || event->keysym.scancode == SDL_SCANCODE_D) && app.selectingDiff == 1){
      app.hardDiff = 1;
    } if ((event->keysym.scancode == SDL_SCANCODE_LEFT || event->keysym.scancode == SDL_SCANCODE_A) && app.selectingDiff == 1){
      app.hardDiff = 0;
    } if (event->keysym.scancode == SDL_SCANCODE_SPACE && app.selectingDiff == 1) {
      app.selectingDiff = 0;
    } if ((event->keysym.scancode == SDL_SCANCODE_RIGHT || event->keysym.scancode == SDL_SCANCODE_D) && app.selectingMode == 1){
      app.classic = 0;
    } if ((event->keysym.scancode == SDL_SCANCODE_LEFT || event->keysym.scancode == SDL_SCANCODE_A) && app.selectingMode == 1){
      app.classic = 1;
    } if (event->keysym.scancode == SDL_SCANCODE_SPACE && app.selectingMode == 1){
      app.selectingMode = 1;
    } if ((event->keysym.scancode == SDL_SCANCODE_RIGHT || event->keysym.scancode == SDL_SCANCODE_D) && app.selectingDesigns == 1){
       player.color += 1;
       player.color %= app.colors;
    } if(event->keysym.scancode == SDL_SCANCODE_M){
      if(!app.muted){
        Mix_VolumeMusic(0);
        app.muted = 1;
      }else{
        Mix_VolumeMusic(128);
        app.muted = 0;
      }
    } if (event->keysym.scancode == SDL_SCANCODE_ESCAPE && (!app.gameFinished && app.gameStart && !menu)){
      app.gameStart = 0;
      app.gameFinished = 1;
      app.menuEnter = 0;
      app.quited = 1;
    } if (event->keysym.scancode == SDL_SCANCODE_R && (!app.gameFinished && app.gameStart && !menu)){
      app.gameFinished = 1;
      app.gameStart = 1;
      app.restarted = 1;
    } if ((event->keysym.scancode == SDL_SCANCODE_LEFT || event->keysym.scancode == SDL_SCANCODE_A) && app.selectingDesigns == 1){
       player.color -= 1;
       if(player.color == -1){
	 player.color = app.colors - 1;
       }
    } if (event->keysym.scancode == SDL_SCANCODE_SPACE && app.selectingDesigns == 1) {
      app.selectingDesigns = 0;
    } if (event->keysym.scancode == SDL_SCANCODE_SPACE && app.onInfo == 1) {
      app.onInfo = 0;
    } if (event->keysym.scancode == SDL_SCANCODE_SPACE && app.selectingMode == 1) {
      app.selectingMode = 0;
    }
  }
}
/*
 * Helper function that handles users input.
 */
void doInput(void) {
  SDL_Event event;
  while (SDL_PollEvent(&event)) {
    switch (event.type) {
    case SDL_QUIT:
      close_pong();
      exit(0);
      break;
    case SDL_KEYDOWN:
      doKeyDown(&event.key);
      break;
    case SDL_KEYUP:
      doKeyUp(&event.key);
      break;
    default:
      break;
    }
  }
}
/*
 * Helper function that uses SDL's framework to clear the current scene.
 */
void prepareScene(void) {
  SDL_SetRenderDrawColor(app.renderer, 0, 0, 0, 255);
  SDL_RenderClear(app.renderer);
}
/*
 * Helper function that uses SDL's framework to draw the current scene.
 */
void presentScene(void) {
  SDL_RenderPresent(app.renderer);
}


/*
 * Loads a texture from a filelocationstring (.PNG image)
 */
SDL_Texture *loadTexture(char *filename) {
  SDL_Texture *texture;
  texture = IMG_LoadTexture(app.renderer, filename);
  return texture;
}
/*
 * Helper function that uses SDL's framework to draw the any textures that
 * relate to images.
 */
void blit(SDL_Texture *texture, int x, int y) {
  SDL_Rect dest;
  dest.x = x;
  dest.y = y;
  SDL_QueryTexture(texture, NULL, NULL, &dest.w, &dest.h);
  SDL_RenderCopy(app.renderer, texture, NULL, &dest);
}
/*
 * Helper function that uses SDL's framework to draw the two paddles.
 */
void blitPaddle(int x, int y, Paddle p, int comp, int color){
  SDL_Rect paddle;
  paddle.x = x;
  paddle.y = y;
  paddle.w = 20;
  paddle.h = p.height;
  if(comp){
    SDL_SetRenderDrawColor(app.renderer, 244, 78, 18, 255 );
  }else{
    if(color == 0){
      SDL_SetRenderDrawColor(app.renderer, 255, 255, 255, 255 );
    }else if(color == 1){
      SDL_SetRenderDrawColor(app.renderer, 160, 32, 255, 255 );
    }else if(color == 2){
      SDL_SetRenderDrawColor(app.renderer, 80, 208, 255, 255 );
    }else if(color == 3){
      SDL_SetRenderDrawColor(app.renderer, 0, 32, 255, 255 );
    }else if(color == 4){
      SDL_SetRenderDrawColor(app.renderer, 0, 192, 0, 255 );
    }else if(color == 5){
      SDL_SetRenderDrawColor(app.renderer, 255, 160, 16, 255);
    }
  }
  SDL_RenderFillRect(app.renderer, &paddle);
}

/*
 * Helper function that uses SDL's framework to draw the ball.
 */
void blit_ball(int x, int y){
  SDL_Rect ball;
  ball.x = x;
  ball.y = y;
  ball.w = 20;
  ball.h = 20;
  SDL_SetRenderDrawColor(app.renderer, 255, 255, 255, 255);
  SDL_RenderFillRect(app.renderer, &ball);
}
/*
 * Displays a black cover of specific size and opacity.
 */
void blit_cover(int x, int y, int o, int sizex, int sizey){
  SDL_Rect mid;
  mid.x = x;
  mid.y = y;
  mid.w = sizex;
  mid.h = sizey;
  SDL_SetRenderDrawBlendMode(app.renderer, SDL_BLENDMODE_BLEND);
  SDL_SetRenderDrawColor(app.renderer, 0, 0, 0, o);
  SDL_RenderFillRect(app.renderer, &mid);
}

/*
 * Helper function that uses SDL's framework to draw the middle line
 * For the game.
 */
void blit_middle(int x, int y, int w, int h){
  SDL_Rect mid;
  mid.x = x;
  mid.y = y;
  mid.w = w;
  mid.h = h;
  SDL_SetRenderDrawColor(app.renderer, 255, 255, 255, 255);
  SDL_RenderFillRect(app.renderer, &mid);
}
/*
 * Displays the difficulty of the computer, to be choosen by the user.
 */
void displayCompDiff(){
  while(app.selectingDiff){
    prepareScene();
    doInput();
    blit(app.easyDifficulty, 50, 250);
    blit(app.hardDifficulty, SCREEN_WIDTH - 550, 250);
    if(app.hardDiff == 0){
      blit(app.arrowup, 250, 500);
    }else{
      blit(app.arrowup, 850, 500);
    }
    presentScene();
  }
}

/*
 * Displays the choices of paddle customization.
 */
void displayDesigns(){
  int space = 176;
  int x;
  while(app.selectingDesigns){
    x = 150;
    prepareScene();
    doInput();
    if(player.color == 0){
      blit(app.arrowup, 150 - 40, 500);
    }else{
      blit(app.arrowup, 110 + (player.color * 176), 500);
    }
    for(int i = 0; i < app.colors; i++){
      blitPaddle(x, 300, player, 0, i);
      x += space;
    }
    presentScene();
  }
}
/*
 * Called to remove other screen aspects and dispaly the user info texture
 */
void drawInfo(){
  while(app.onInfo){
    prepareScene();
    doInput();
    blit(app.background, 0, 0);
    blit(app.infoText, 10, 30);
    presentScene();
  }
}
/*
 * Called to remove other screen aspects and display 
 */
void displayMode(){
  while(app.selectingMode){
    prepareScene();
    doInput();
    blit(app.classicImg, 50, 250);
    blit(app.doublesImg, SCREEN_WIDTH - 550, 250);
    if(app.classic == 1){
      blit(app.arrowup, 250, 500);
    }else{
      blit(app.arrowup, 850, 500);
    }
    presentScene();
  }
}

/*
 * Handles the main menu as well as all the drawings needed for the game
 * itself.
 */
void drawKit(){
  if (menu == 1) {
    while (menu == 1) {
      if (menuCheck == 6) {
	menuCheck = 1;
      } if (menuCheck == 0) {
	menuCheck = 5;
      } if (app.menuEnter == 1) {
	if (menuCheck == 1) {
	  app.selectingDiff = 1;
	  displayCompDiff();
	  app.menuEnter = 0;
	}else if (menuCheck == 2){
	  app.onInfo = 1;
	  drawInfo();
	  app.menuEnter = 0;
	}else if (menuCheck == 3){
	  menu = 0;
	}else if (menuCheck == 4){
	  app.selectingDesigns = 1;
	  displayDesigns();
	  app.menuEnter = 0;
	}else if (menuCheck == 5){
	  app.selectingMode = 1;
	  displayMode();
	  app.menuEnter = 0;
	}
      }
      doInput();
      prepareScene();
      blit(app.background,0,0);
      blit(app.difficulty, 100, 0);
      blit(app.info, 100, 100);
      blit(app.play, 100, 200);
      blit(app.color,100, 300);
      blit(app.mode, 100, 400);
      blit(app.interact, 400, 200);
      blit(app.initialsImg, 900, 650);
      if(menuCheck == 1){
	blit(app.arrow, 250, 0);
      }else{
	blit(app.arrow, 250, (menuCheck-1)*100);
      }
      presentScene();
    }
  }
  else {
    if (app.gameFinished != 1) {
      blit(scoreBoard.playerScore, pScoreCoor[0], pScoreCoor[1]);
      blit(scoreBoard.compScore, cScoreCoor[0], cScoreCoor[1]);
    }
    else if(!app.quited && !app.restarted){
      blit(app.playAgain, 100, 0);
      blit(app.returnMenu, 100, 70);
    }
    blitPaddle(player.x, player.y, player, 0, player.color);
    blitPaddle(computer.x, computer.y, computer, 1, player.color);
    if(!app.classic){
      blitPaddle(playerNet.x, playerNet.y, playerNet, 0, player.color);
      blitPaddle(computerNet.x, computerNet.y, computerNet, 1, player.color);
    }
    blit_ball(ball.x, ball.y);
    blit_middle(50, 70, 15, SCREEN_HEIGHT - 140); // left
    blit_middle(SCREEN_WIDTH - 50, 70, 15, SCREEN_HEIGHT - 140); // right
    blit_middle(50, SCREEN_HEIGHT - 70, SCREEN_WIDTH - 85, 15); // bottom
    blit_middle(50, 70, SCREEN_WIDTH - 85, 15);
    if(player.speed == 2){
      blit(powerUp.slowDownImg, 10, 290);
      blit_cover(10, 290, (int)(time(NULL) - slowDownStartP) * 25.5, 20, 20);
    }if(player.speed == 8){
      blit(powerUp.speedUpImg, 10, 330);
      blit_cover(10, 330, (int)(time(NULL) - speedUpStartP) * 25.5, 20, 20);
    }if(player.height == 150){
      blit(powerUp.enlargeImg, 10, 370);
      blit_cover(10, 370, (int)(time(NULL) - enlargeStartP) * 25.5, 20, 20);
    }if(player.height == 75){
      blit(powerUp.shrinkImg, 10, 410);
      blit_cover(10, 410, (int)(time(NULL) - shrinkStartP) * 25.5, 20, 20);
    }if(computer.speed == 2){
      blit(powerUp.slowDownImg, SCREEN_WIDTH-30, 290);
      blit_cover(SCREEN_WIDTH-30, 290, (int)(time(NULL) - slowDownStartC) * 25.5, 20, 20);
    }if(computer.speed == 8){
      blit(powerUp.speedUpImg, SCREEN_WIDTH-30, 330);
      blit_cover(SCREEN_WIDTH-30, 330, (int)(time(NULL) - speedUpStartC) * 25.5, 20, 20);
    }if(computer.height == 150){
      blit(powerUp.enlargeImg, SCREEN_WIDTH-30, 370);
      blit_cover(SCREEN_WIDTH-30, 370, (int)(time(NULL) - enlargeStartC) * 25.5, 20, 20);
    }if(computer.height == 75){
      blit(powerUp.shrinkImg, SCREEN_WIDTH-30, 410);
      blit_cover(SCREEN_WIDTH-30, 410, (int)(time(NULL) - shrinkStartC) * 25.5, 20, 20);
    }if(powerUp.playerLight){
      blit(powerUp.lightbadImg, 10, 440);
      blit_cover(10, 440, (int)(time(NULL) - lightbadStartP) * 25.5, 20, 20);
    }if(powerUp.compLight){
      blit(powerUp.lightbadImg, SCREEN_WIDTH-30, 440);
      blit_cover(SCREEN_WIDTH-30, 440, (int)(time(NULL) - lightbadStartC) * 25.5, 20, 20);
    }
  }
}
/*
 * Displays the end screen after the game is completed and waits for user's
 * input to continue.
 */
void gameOver(int compWon){
  if(compWon){
    app.endScreen = loadTexture("images/cwins.png");
  }else{
    app.endScreen = loadTexture("images/pwins.png");
  }
  SDL_Event event;
  int waiting = 1;
  while (app.gameFinished) {
    prepareScene();
    doInput();
    drawKit();
    if(compWon){
      blit(app.endScreen, 620, border.top + 50);
    }else{
      blit(app.endScreen, border.left + 25, border.top + 50);
    }
    presentScene();
    SDL_Delay(16);
  }
}
/*
 * Utility method used to handle timer Powerup
 */
void handleTimer(){
  if(player.speed == 2 && time(NULL) - slowDownStartP > 10){
      player.speed = playerNet.speed = 4;
  }if(computer.speed == 2 && time(NULL) - slowDownStartC > 10){
      computer.speed = computerNet.speed = 4;
  }if(player.speed == 8 && time(NULL) - speedUpStartP > 10){
      player.speed = playerNet.speed = 4;
  }if(computer.speed == 8 && time(NULL) - speedUpStartC > 10){
      computer.speed = computerNet.speed = 4;
  }if(player.height == 75 && time(NULL) - shrinkStartP > 10){
      player.height = playerNet.height = PADDLE_HEIGHT;
  }if(computer.height == 75 && time(NULL) - shrinkStartC > 10){
      computer.height = computerNet.height = PADDLE_HEIGHT;
  }if(player.height == 150 && time(NULL) - enlargeStartP > 10){
      player.height = playerNet.height = PADDLE_HEIGHT;
  }if(computer.height == 150 && time(NULL) - enlargeStartC > 10){
      computer.height = computerNet.height = PADDLE_HEIGHT;
  }
}
/*
 * Covers palyer screen, for use with 'light' powerup
 */
void handlePlayerLight(){
  if(time(NULL) - lightbadStartP > 6){
    powerUp.playerLight = 0;
  } else if((time(NULL) - lightbadStartP) % 2 == 0){
    blit_cover(0, 0, 255, SCREEN_WIDTH, SCREEN_HEIGHT);
  }
}

/*
 * Spawns a random power up that is not already there.
 */
void spawnPowerUp(){
  int randomNumber = rand() % 6;
  int randx = (rand() % 801) + 200;
  int randy = (rand() % ((border.bottom - powerUp.height) - border.top + 10)) + (border.top);
  if(randomNumber == 0 && powerUp.speedUp != 1){
    powerUp.speedUp = 1;
    powerUp.speedUpLoc[0] = randx;
    powerUp.speedUpLoc[1] = randy;
  }else if(randomNumber == 1 && powerUp.slowDown != 1){
    powerUp.slowDown = 1;
    powerUp.slowDownLoc[0] = randx;
    powerUp.slowDownLoc[1] = randy;
  }else if(randomNumber == 2 && powerUp.enlarge != 1){
    powerUp.enlarge = 1;
    powerUp.enlargeLoc[0] = randx;
    powerUp.enlargeLoc[1] = randy;
  }else if(randomNumber == 3 && powerUp.shrink != 1){
    powerUp.shrink = 1;
    powerUp.shrinkLoc[0] = randx;
    powerUp.shrinkLoc[1] = randy;
  }else if(randomNumber == 4 && powerUp.lightgood != 1){
    powerUp.lightgood = 1;
    powerUp.lightgoodLoc[0] = randx;
    powerUp.lightgoodLoc[1] = randy;
  }else if(randomNumber == 5 && powerUp.lightbad != 1){
    powerUp.lightbad = 1;
    powerUp.lightbadLoc[0] = randx;
    powerUp.lightbadLoc[1] = randy;
  }
}

/*
 * Draws one of the powerups that was recently spawed.
 */
void drawPowerUp(){
  if(powerUp.speedUp){
    blit(powerUp.speedUpImg, powerUp.speedUpLoc[0],powerUp.speedUpLoc[1]);
  }if(powerUp.slowDown){
    blit(powerUp.slowDownImg, powerUp.slowDownLoc[0],powerUp.slowDownLoc[1]);
  }if(powerUp.enlarge){
    blit(powerUp.enlargeImg, powerUp.enlargeLoc[0],  powerUp.enlargeLoc[1]);
  }if(powerUp.shrink){
    blit(powerUp.shrinkImg, powerUp.shrinkLoc[0], powerUp.shrinkLoc[1]);
  }if(powerUp.lightgood){
    blit(powerUp.lightgoodImg, powerUp.lightgoodLoc[0], powerUp.lightgoodLoc[1]);
  }if(powerUp.lightbad){
    blit(powerUp.lightbadImg, powerUp.lightbadLoc[0], powerUp.lightbadLoc[1]);
  }
}

/*
 * Calculates the velocity of the ball when it hits one of the players.
 */
void calc_velocity(int pad) {
  double relative_intersection;
  double normalized_intersection;
  double bounceAngle;
  if(pad == 0){
    relative_intersection = player.height/2 - (player.height - (ball.y - player.y));
    normalized_intersection = (relative_intersection / (player.height/2));
  }else if(pad == 1){
    relative_intersection = playerNet.height/2 - (playerNet.height - (ball.y - playerNet.y));
    normalized_intersection = (relative_intersection / (playerNet.height/2));
  }else if(pad == 2){
    relative_intersection = computerNet.height/2 - (computerNet.height - (ball.y - computerNet.y));
    normalized_intersection = (relative_intersection / (computerNet.height/2));
  }else{
    relative_intersection = computer.height/2 - (computer.height - (ball.y - computer.y));
    normalized_intersection = (relative_intersection / (computer.height/2));
  }
  bounceAngle = normalized_intersection * MAX_BOUNCE;
  ball.vy = 5 * sin(bounceAngle);
  if(pad != 0 || pad != 1){
    invisibleBall.reached = 0;
    invisibleBall.vy = ball.vy * 2;
    invisibleBall.x = ball.x;
    invisibleBall.y = ball.y;
  }
  app.rally += 1;
  if(app.rally % powerUp.spawnRate == 0 && app.rally != 0){
    spawnPowerUp();
  }
}

/*
 * Helper function called by check_collisions, determines if the ball has
 * made contancet with a power up.
 */
int powerUpCollision(int x, int y){
  if((((x <= ball.x && ball.x <= x + powerUp.height) || (x <= ball.x + ball.height && ball.x + ball.height <= x + powerUp.height)) &&
      ((y <= ball.y && ball.y <= y + powerUp.height) || (y <= ball.y + ball.height && ball.y + ball.height <= y + powerUp.height)))){
    return 1;
  }else{
    return 0;
  }
}

/*
 * Checks for various collisions; ball to wall, ball to player/comp,
 * ball to power up and ball to goal.
 */
void check_collision(){
  if(ball.x == 120 && (player.y - ball.height <= ball.y && ball.y <= player.y + player.height)){
    ball.left = 0;
    calc_velocity(0);
  }else if(!app.classic && ball.x == playerNet.x + player.width && (playerNet.y - ball.height <= ball.y 
    && ball.y <= playerNet.y + playerNet.height)){
    ball.left = 0;
    calc_velocity(1);
  }else if(ball.x >= border.right - border.width){ // player won point.
    ball.left = 1;
    app.roundDone = 1;
    scoreBoard.score[0] += 1;
    if(scoreBoard.score[0] == 10){
      app.gameFinished = 1;
    }
    scoreBoard.playerScore = loadTexture(playerPictures[scoreBoard.score[0]]);
  }else if(ball.x <= border.left){ // comp won point.
    ball.left = 0;
    app.roundDone = 1;
    scoreBoard.score[1] += 1;
    if(scoreBoard.score[1] == 10){
      app.gameFinished = 1;
    }
    scoreBoard.compScore = loadTexture(compPictures[scoreBoard.score[1]]);
  }else if(ball.y + ball.height >= border.bottom || ball.y <= border.top){ // bounce off bottom or top.
    ball.vy = ball.vy * -1;
  }else if(!app.classic && ball.x == computerNet.x - computerNet.width && ((ball.y + ball.height) >= computerNet.y 
    && computerNet.y + computerNet.height >= ball.y)){
    calc_velocity(2);
    ball.left = 1;
  }else if(ball.x == computer.x - computer.width && ((ball.y + ball.height) >= computer.y 
    && computer.y + computer.height >= ball.y)){
    calc_velocity(3);
    ball.left = 1;
  }if(powerUp.speedUp && powerUpCollision(powerUp.speedUpLoc[0], powerUp.speedUpLoc[1])){
    if(ball.left){
      speedUpStartC = time(NULL);
      computer.speed = computerNet.speed = 8;
    }else{
      speedUpStartP = time(NULL);
      player.speed = playerNet.speed = 8;
    }
    powerUp.speedUp = 0;
  }else if(powerUp.slowDown && powerUpCollision(powerUp.slowDownLoc[0], powerUp.slowDownLoc[1])){
    if(ball.left){
      slowDownStartC = time(NULL);
      computer.speed = computerNet.speed = 2;
    }else{
      slowDownStartP = time(NULL);
      player.speed = playerNet.speed = 2;
    }
    powerUp.slowDown = 0;
  }else if(powerUp.enlarge && powerUpCollision(powerUp.enlargeLoc[0], powerUp.enlargeLoc[1])){
    if(ball.left){
      enlargeStartC = time(NULL);
      computer.height = computerNet.height = 150;
    }else{
      enlargeStartP = time(NULL);
      player.height = playerNet.height = 150;
    }
    powerUp.enlarge = 0;
  }else if(powerUp.shrink && powerUpCollision(powerUp.shrinkLoc[0], powerUp.shrinkLoc[1])){
    if(ball.left){
      shrinkStartC = time(NULL);
      computer.height = computerNet.height = 75;
    }else{
      shrinkStartP = time(NULL);
      player.height = playerNet.height = 75;
    }
    powerUp.shrink = 0;
  }else if(powerUp.lightgood && powerUpCollision(powerUp.lightgoodLoc[0], powerUp.lightgoodLoc[1])){
    if(ball.left){
      lightbadStartP = time(NULL);
      powerUp.playerLight = 1;
    }else{
      lightbadStartC = time(NULL);
      powerUp.compLight = 1;
    }
    powerUp.lightgood = 0;
  }else if(powerUp.lightbad && powerUpCollision(powerUp.lightbadLoc[0], powerUp.lightbadLoc[1])){
    if(ball.left){
      lightbadStartC = time(NULL);
      powerUp.compLight = 1;
    }else{
      lightbadStartP = time(NULL);
      powerUp.playerLight = 1;
    }
    powerUp.lightbad = 0;
  } if(invisibleBall.x >= SCREEN_WIDTH - 130){
    invisibleBall.reached = 1;
  }
  if(invisibleBall.y + ball.height >= border.bottom || invisibleBall.y <= border.top){ // bounce off bottom or top.
    invisibleBall.vy = invisibleBall.vy * -1;
  }
}
/*
 * Moves the 'easy' computer
 */
void moveComputer(){
  if(ball.y + ball.height <= computer.y){
    computer.y -= computer.speed;
  }else if(computer.y + computer.height <= ball.y + ball.height/2){
    computer.y += computer.speed;
  }
  if(!app.classic){
    if(ball.y + ball.height <= computerNet.y){
    computerNet.y -= computerNet.speed;
  }else if(computerNet.y + computerNet.height <= ball.y + ball.height/2){
    computerNet.y += computerNet.speed;
  }
  }
}
/*
 * Moves the 'hard' computer
 */
void moveComputerHard(){
  if(invisibleBall.y <= computer.y){
    computer.y -= computer.speed;
  }else if(computer.y + computer.height <= invisibleBall.y + ball.height/2){
    computer.y += computer.speed;
  }
  if(!app.classic){
    if(invisibleBall.y <= computerNet.y){
    computerNet.y -= computerNet.speed;
  }else if(computerNet.y + computerNet.height <= invisibleBall.y + ball.height/2){
    computerNet.y += computerNet.speed;
  }
  }
}
/*
 * Sets the intial positions and attributes of each object, gets called after
 * each point from the runGame method.
 */
void setPos(){
  app.roundDone = 0;
  app.rally = 0;
  app.selectingDiff = 0;
  app.selectingDesigns = 0;
  app.onInfo = 0;
  app.selectingMode = 0;
  app.quited = 0;
  app.restarted = 0;
  app.colors = 6;
  player.x = 100;
  playerNet.x = player.x + 350;
  player.y = playerNet.y = 300;
  player.speed = playerNet.speed = 4;
  player.height = playerNet.height = PADDLE_HEIGHT;

  computer.x = SCREEN_WIDTH - 100;
  computerNet.x = computer.x - 350;
  computer.y = computerNet.y = 300;
  computer.speed = computerNet.speed = 4;
  computer.height = computerNet.height = PADDLE_HEIGHT;

  ball.x = invisibleBall.x = 600;
  ball.y = invisibleBall.y = 250 + (rand() % 201);
  ball.left = invisibleBall.left = rand() % 2;

  ball.vx = 10;
  invisibleBall.vx = ball.vx * 2;
  ball.vy = invisibleBall.vy = 0;
  invisibleBall.reached = 0;

  powerUp.spawned = 0;
  powerUp.speedUp = 0;
  powerUp.slowDown = 0;
  powerUp.enlarge = 0;
  powerUp.shrink = 0;
  powerUp.playerLight = 0;
  powerUp.compLight = 0;
  powerUp.lightbad = 0;
  powerUp.lightgood = 0;
}

/*
 * Main Game loop, gets called once during the third while loop in the main
 * method.
 */
void runGame(){
  while (!app.gameFinished) {
    if(app.roundDone){
      setPos();
    }
    prepareScene();
    doInput();
    handleTimer();
    if(app.up && player.y >= border.top) {
      player.y -= player.speed;
    } else if(app.down && (player.y + player.height <= border.bottom)) {
      player.y += player.speed;
    }
    if(!app.classic){
      if (app.netUp && playerNet.y >= border.top) {
        playerNet.y -= playerNet.speed;
      } else if(app.netDown && (playerNet.y + playerNet.height <= border.bottom)){
        playerNet.y += playerNet.speed;
      }
    }
    if(!ball.left){
      if(powerUp.compLight){
        if(((time(NULL) - lightbadStartC) % 2 != 0)){
          if(app.hardDiff){
            moveComputerHard();
          }
        }else{
          moveComputer();
        }
      }else{
        if(app.hardDiff){
          moveComputerHard();
        }else{
          moveComputer();
        }
      }
    }
    if(ball.left){
      ball.x -= ball.vx;
    }else{
      ball.x += ball.vx;

    }
    ball.y += ball.vy;
    if(!ball.left && invisibleBall.reached == 0){
      invisibleBall.y += invisibleBall.vy;
      invisibleBall.x += invisibleBall.vx;
    }
    drawKit();
    int y = border.top - 15;
    for(int i = 0; i < 8; i++){
      blit_middle(595, y, 10, 40);
      y += 75;
    }
    drawPowerUp();
    if(powerUp.playerLight){
      handlePlayerLight();
    }
    presentScene();
    check_collision();
    SDL_Delay(16);
  }
}
/*
 * Initializes a new game state. Also recognizes whether game was restarted from menu or 'r' key
 */
void initGame(int restarted){
  setPos();
  ball.width = invisibleBall.width = 20;
  ball.height = invisibleBall.height = 20;
  app.gameFinished = 0;
  app.gameStart = 0;
  app.menuEnter = 0;
  scoreBoard.score[0] = 0;
  scoreBoard.score[1] = 0;
  scoreBoard.playerScore = loadTexture("images/0p.png");
  scoreBoard.compScore = loadTexture("images/0c.png");
  menuCheck = 1;
  while (menu == 1){
    drawKit();
  }
  if(!restarted){
    while(!app.gameStart && menu == 0){
      prepareScene();
      doInput();
      blit(scoreBoard.playerScore, pScoreCoor[0], pScoreCoor[1]);
      blit(scoreBoard.compScore, cScoreCoor[0], cScoreCoor[1]);
      blitPaddle(player.x, player.y, player, 0, player.color);
      blitPaddle(computer.x, computer.y, computer, 1, player.color);
      if(!app.classic){
        blitPaddle(playerNet.x, playerNet.y, playerNet, 0, player.color);
        blitPaddle(computerNet.x, computerNet.y, computerNet, 1, player.color);
      }
      blit(app.titleScreen, 0, 0);
      blit_middle(50, 70, 15, SCREEN_HEIGHT-140); // left
      blit_middle(SCREEN_WIDTH-50, 70, 15, SCREEN_HEIGHT-140); // right
      blit_middle(50, SCREEN_HEIGHT-70, SCREEN_WIDTH-85, 15); // bottom
      blit_middle(50, 70, SCREEN_WIDTH-85, 15); // top
      presentScene();
    }
  }
  app.gameStart = 1;
}

/*
 * Main Driver code, used for memory assignment, runs the main menu and game
 * First while loop handles the main menu
 * Second while loop handles the start of the game waiting for the user to press
 * spacebar to start.
 * Thrid while loop handles the end game screen
 */
int main( int argc, char* args[]){
  memset(&app, 0, sizeof(App));
  memset(&player, 0, sizeof(Paddle));
  memset(&ball, 0, sizeof(Ball));
  memset(&ball, 0, sizeof(Ball));
  memset(&computer, 0, sizeof(Paddle));
  memset(&scoreBoard, 0, sizeof(ScoreBoard));
  memset(&border, 0, sizeof(Border));
  memset(&powerUp, 0, sizeof(PowerUp));
  memset(&playerNet, 0, sizeof(Paddle));
  memset(&computerNet, 0, sizeof(Paddle));

  initSDL();
  player.color = 0;
  player.width = playerNet.width = PADDLE_WIDTH;
  computer.width = computerNet.width = PADDLE_WIDTH;
  app.titleScreen = loadTexture("images/title.png");
  app.playAgain = loadTexture("images/playagain.png");
  app.returnMenu = loadTexture("images/returnMenu.png");
  app.difficulty = loadTexture("images/difficulty.png");
  app.easyDifficulty = loadTexture("images/easy.png");
  app.hardDifficulty = loadTexture("images/hard.png");
  app.info = loadTexture("images/info.png");
  app.play = loadTexture("images/play.png");
  app.color = loadTexture("images/color.png");
  app.arrow = loadTexture("images/arrow.png");
  app.arrowup = loadTexture("images/arrowup.png");
  app.background = loadTexture("images/background.png");
  app.infoText = loadTexture("images/infoText.png");
  app.interact = loadTexture("images/interact.png");
  app.mode = loadTexture("images/mode.png");
  app.classicImg = loadTexture("images/classic.png");
  app.doublesImg = loadTexture("images/doubles.png");
  app.initialsImg = loadTexture("images/initials.png");
  app.muted = 0;
  app.quited = 0;
  app.restarted = 0;
  app.hardDiff = 0;
  app.classic = 1;
  border.width = 15;
  border.top = 70 + border.width;
  border.bottom = SCREEN_HEIGHT-70;
  border.left = 50 + border.width;
  border.right = SCREEN_WIDTH - 50;
  powerUp.height = 20;
  powerUp.spawnRate = 2;
  powerUp.speedUpImg = loadTexture("images/speedup.png");
  powerUp.slowDownImg = loadTexture("images/slowdown.png");
  powerUp.enlargeImg = loadTexture("images/enlarge.png");
  powerUp.shrinkImg = loadTexture("images/shrink.png");
  powerUp.lightgoodImg = loadTexture("images/lightgood.png");
  powerUp.lightbadImg = loadTexture("images/lightbad.png");
  music1 = Mix_LoadMUS("sounds/music1.wav");
  music2 = Mix_LoadMUS("sounds/music2.wav");
  music3 = Mix_LoadMUS("sounds/music3.wav");
  if(music1 == NULL || music2 == NULL || music3 == NULL) {
    printf("Failed to load sound\n");
    return EXIT_FAILURE;
  }
  Mix_PlayMusic(music1, -1);
  initGame(0);
  
  while(1){
    while(menu==0){
      runGame();
      if(scoreBoard.score[0] == 10){
	      gameOver(0);
      }else if(scoreBoard.score[1] == 10){
	      gameOver(1);
      }
      if(!app.menuEnter && !app.gameStart){
	      menu = 1;
	      initGame(0);
        continue;
      }
      initGame(1);
    }
    close_pong();
  }
  return EXIT_SUCCESS;
}
