To compile the Alpha build:
gcc pong.c -F/Library/Frameworks/SDL2.framework/Headers -framework SDL2 -F/Library/Frameworks/SDL2_image.framework/Headers -framework SDL2_image -o pong
from a terminal window

To run the alpha build:
In a terminal window:
./pong/pong