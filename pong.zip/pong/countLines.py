"""
Helper program to count the lines for the main pong.c file
to run: python3 countLines.py
"""
with open('pong.c', 'r') as f:
    lines = f.readlines()
    amount = 0
    for line in lines:
        if len(line) != 1 and line[1] != '*' and line[0] != '/':
            amount += 1
    print('line count:', amount)
